public class ForStmt extends Stmt {
    private Expr initialExpr;
    private Expr condition;
    private Stmt body;
    private Expr stepExpr;

    ForStmt(Expr initialExpr, Expr condition, Stmt body, Expr stepExpr) {
        this.initialExpr = initialExpr;
        this.condition = condition;
        this.body = body;
        this.stepExpr = stepExpr;
    }

    @Override
    void coder(Coder coder) {
        String label1 = coder.newLabel(), label2 = coder.newLabel();
        coder.addScope();
        coder.pushLoop(label2);
        if (initialExpr != null) {
            initialExpr.coder(coder);
        }
        coder.addText(String.format("%s:", label1));
        condition.coder(coder);
        coder.addText(String.format("lw    $s0,%d($fp)", condition.variableDecl.location));
        coder.addText(String.format("beq $s0,$zero,%s", label2));
        body.coder(coder);
        if (stepExpr != null) {
            stepExpr.coder(coder);
        }
        coder.addText(String.format("j %s", label1));
        coder.addText(String.format("%s:", label2));
        coder.popScope();
        coder.popLoop();
    }
}
