import java.util.ArrayList;
import java.util.HashMap;

abstract public class Decl {
    abstract public void coder(Coder coder);
}

class ClassDecl extends Decl {
    String classLabel;
    ID id;
    ArrayList<VariableDecl> fields = new ArrayList<>();
    ArrayList<FunctionDecl> methods = new ArrayList<>();
    private ClassType par;
    private boolean isAdded;

    ClassDecl(ClassType par, ID id, ArrayList<Decl> fields) {
        this.par = par;
        this.id = id;
        for (Decl decl : fields) {
            if (decl instanceof VariableDecl) {
                this.fields.add((VariableDecl) decl);
            } else {
                this.methods.add((FunctionDecl) decl);
            }
        }
        for (FunctionDecl method : methods) {
            method.parClass = new ClassType(id);
            method.init();
        }
        classLabel = "ClassVtable_" + id.name;
    }


    void addFields(Coder coder) {
        if (par == null || isAdded)
            return;

        ClassDecl parDecl = coder.classTable.get(par.id);
        parDecl.addFields(coder);

        ArrayList<FunctionDecl> newMethods = parDecl.methods;
        ArrayList<VariableDecl> newFields = parDecl.fields;

        for (VariableDecl variableDecl : fields) {
            boolean exists = false;
            for (VariableDecl variableDecl1 : newFields) {
                if (variableDecl.id.equals(variableDecl1.id)) {
                    exists = true;
                }
            }
            if (!exists) {
                newFields.add(variableDecl);
            }
        }
        for (FunctionDecl functionDecl : methods) {
            boolean exists = false;
            for (int i = 0; i < newMethods.size(); i++) {
                if (functionDecl.id.equals(newMethods.get(i).id)) {
                    newMethods.set(i, functionDecl);
                    exists = true;
                }
            }
            if (!exists) {
                newMethods.add(functionDecl);
            }
        }
        isAdded = true;
        fields = newFields;
        methods = newMethods;
    }

    @Override
    public void coder(Coder coder) {
        coder.funcTable.add(new HashMap<>());
        coder.addScope();
        for (FunctionDecl method : methods) {
            coder.funcTable.get(1).put(method.id, method);
        }
        int ptr = 0;
        for (VariableDecl field : fields) {
            coder.topScope().put(field.id, field);
            ptr += 4;
            field.location = ptr;
            field.variableType = VariableType.FIELD;
        }
        for (FunctionDecl method : methods) {
            if (method.parClass.id.equals(id)) {
                method.coder(coder);
            }
        }
        coder.popScope();
        coder.funcTable.remove(1);
    }

    void addVtable(Coder coder) {
        coder.addData(classLabel + ":");
        coder.addData(String.format(".space %d", 4 * methods.size()));
    }

    int offsetOfMethod(ID id) {
        for (int i = 0; i < methods.size(); i++) {
            if (methods.get(i).id.equals(id)) {
                return 4 * i;
            }
        }
        return 0;
    }

    FunctionDecl getMethod(ID id) {
        for (FunctionDecl method : methods) {
            if (method.id.equals(id)) {
                return method;
            }
        }
        return null;
    }
}

