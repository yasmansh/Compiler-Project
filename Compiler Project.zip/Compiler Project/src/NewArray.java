public class NewArray extends Expr {
    Expr expr;
    Type type;

    NewArray(Expr expr, Type type) {
        this.expr = expr;
        this.type = type;
    }

    @Override
    void coder(Coder coder) {
        expr.coder(coder);
        this.variableDecl = new VariableDecl(new ArrayType(type), null);
        this.variableDecl.location = coder.newLocation();
        this.variableDecl.variableType = VariableType.LOCAL;
        coder.addText(String.format("lw $s0,%d($fp)", expr.variableDecl.location));
        coder.addText("addi $a0,$s0,1");
        coder.addText("sll $a0,$a0,2");
        coder.addText("li $v0,9"); // syscall for memory allocation
        coder.addText("syscall");
        coder.addText("sw $s0,0($v0)"); // v0: addr
        coder.addText(String.format("sw $v0,%d($fp)", this.variableDecl.location));
    }
}