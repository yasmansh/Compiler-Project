class ArithmeticExpr extends Expr {
    private Expr firstOperand, secondOperand;
    private OperatorType operatorType;

    ArithmeticExpr(Expr operand, String operator) {
        this.firstOperand = operand;
        setOperatorType(operator, true);
    }

    ArithmeticExpr(Expr firstOperand, String operator, Expr secondOperand) {
        this.firstOperand = firstOperand;
        this.secondOperand = secondOperand;
        setOperatorType(operator, false);
    }

    private void setOperatorType(String operator, boolean isSyngleOperator) {
        if (isSyngleOperator) {
            if (operator.equals("!"))
                this.operatorType = OperatorType.NOT;
            if (operator.equals("-"))
                this.operatorType = OperatorType.SINGLESUB;
        } else {
            if (operator.equals("||"))
                this.operatorType = OperatorType.OR;
            if (operator.equals("&&"))
                this.operatorType = OperatorType.AND;
            if (operator.equals("<"))
                this.operatorType = OperatorType.L;
            if (operator.equals("<="))
                this.operatorType = OperatorType.LE;
            if (operator.equals(">"))
                this.operatorType = OperatorType.G;
            if (operator.equals(">="))
                this.operatorType = OperatorType.GE;
            if (operator.equals("=="))
                this.operatorType = OperatorType.E;
            if (operator.equals("!="))
                this.operatorType = OperatorType.NE;
            if (operator.equals("+"))
                this.operatorType = OperatorType.ADD;
            if (operator.equals("-"))
                this.operatorType = OperatorType.SUB;
            if (operator.equals("*"))
                this.operatorType = OperatorType.MUL;
            if (operator.equals("/"))
                this.operatorType = OperatorType.DIV;
            if (operator.equals("%"))
                this.operatorType = OperatorType.MOD;
        }
    }

    @Override
    void coder(Coder coder) {
        firstOperand.coder(coder);
        if (secondOperand != null)
            secondOperand.coder(coder);
        coder.addText(String.format("lw $s0,%d($fp)", firstOperand.variableDecl.location));
        if (operatorType == OperatorType.NOT || operatorType == OperatorType.SINGLESUB) {
            if (operatorType == OperatorType.NOT) {
                coder.addText("nor $s4,$s0,$s0");
                this.variableDecl = new VariableDecl(Type.boolType);
            } else { // for -n
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $zero,$f1");
                    coder.addText("sub.s $f2,$f1,$f0");
                    coder.addText("mfc1 $s4,$f2");
                    this.variableDecl = new VariableDecl(Type.doubleType);
                } else if (firstOperand.variableDecl.type == Type.intType) {
                    coder.addText("sub $s4,$zero,$s0");
                    this.variableDecl = new VariableDecl(Type.intType);
                }
            }
        } else { // two operands
            coder.addText(String.format("lw $s1,%d($fp)", secondOperand.variableDecl.location));
            if (operatorType == OperatorType.OR || operatorType == OperatorType.AND) {
                coder.addText(operatorType.toString().toLowerCase() + " $s4,$s0,$s1");
                this.variableDecl = new VariableDecl(Type.boolType);
            } else if ( operatorType == OperatorType.L) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    String label1 = coder.newLabel();
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText("c.lt.s $f0,$f1");
                    coder.addText("li $s4,1");
                    coder.addText(String.format("bc1t %s", label1));
                    coder.addText("li $s4,0");
                    coder.addText(String.format("%s: ", label1));
                    this.variableDecl = new VariableDecl(Type.boolType);
                } else if (firstOperand.variableDecl.type == Type.intType) {
                    coder.addText("s" + operatorType.toString().toLowerCase() + "t $s4,$s0,$s1");
                    this.variableDecl = new VariableDecl(Type.boolType);
                }
            }  else if (operatorType == OperatorType.G ) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    String label1 = coder.newLabel();
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText("c.lt.s $f0,$f1");//c.gt.s or c.lt.s
                    coder.addText("li $s4,1");
                    coder.addText(String.format("bc1t %s", label1));
                    coder.addText("li $s4,0");
                    coder.addText(String.format("%s: ", label1));
                    this.variableDecl = new VariableDecl(Type.boolType);
                } else if (firstOperand.variableDecl.type == Type.intType) {
                    coder.addText("sgt $s4,$s0,$s1");
                    this.variableDecl = new VariableDecl(Type.boolType);
                }
            }else if (operatorType == OperatorType.GE) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    String label1 = coder.newLabel();
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText("c.lt.s $f0,$f1");
                    coder.addText("li $s4,0");
                    coder.addText(String.format("bc1t %s", label1));
                    coder.addText("li $s4,1");
                    coder.addText(String.format("%s: ", label1));
                    this.variableDecl = new VariableDecl(Type.boolType);
                } else if (firstOperand.variableDecl.type == Type.intType) {
                    coder.addText("slt $s5,$s0,$s1");
                    coder.addText("seq $s4,$s5,$zero");
                    this.variableDecl = new VariableDecl(Type.boolType);
                }
            } else if (operatorType == OperatorType.LE) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    String label1 = coder.newLabel();
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText("c.gt.s $f0,$f1");
                    coder.addText("li $s4,0");
                    coder.addText(String.format("bc1t %s", label1));
                    coder.addText("li $s4,1");
                    coder.addText(String.format("%s: ", label1));
                    this.variableDecl = new VariableDecl(Type.boolType);
                } else if (firstOperand.variableDecl.type == Type.intType) {
                    coder.addText("sgt $s5,$s0,$s1");
                    coder.addText("seq $s4,$s5,$zero");
                    this.variableDecl = new VariableDecl(Type.boolType);
                }
            } else if (operatorType == OperatorType.E) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    String label1 = coder.newLabel();
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText("c.eq.s $f0,$f1");
                    coder.addText("li $s4,1");
                    coder.addText(String.format("bc1t %s", label1));
                    coder.addText("li $s4,0");
                    coder.addText(String.format("%s: ", label1));
                    this.variableDecl = new VariableDecl(Type.boolType);
                } else if (firstOperand.variableDecl.type == Type.boolType ||
                        firstOperand.variableDecl.type == Type.intType ||
                        firstOperand.variableDecl.type == Type.nullType ||
                        firstOperand.variableDecl.type instanceof ClassType ||
                        firstOperand.variableDecl.type instanceof ArrayType) {
                    coder.addText("seq $s4,$s1,$s0");
                    this.variableDecl = new VariableDecl(Type.boolType);
                } else if (firstOperand.variableDecl.type == Type.stringType) {
                    String label1 = coder.newLabel(), label2 = coder.newLabel(), label3 = coder.newLabel();
                    coder.addText("li $s4,1");
                    coder.addText(String.format("%s: ", label1));
                    coder.addText("lb $s2,0($s0)");
                    coder.addText("lb $s3,0($s1)");
                    coder.addText(String.format("beq $s2,$s3,%s", label2));
                    coder.addText("li $s4,0");
                    coder.addText(String.format("j %s", label3));
                    coder.addText(label2 + ": ");
                    coder.addText("addi $s1,$s1,1");
                    coder.addText("addi $s0,$s0,1");
                    coder.addText(String.format("bne $s2,$zero,%s", label1));
                    coder.addText(String.format("%s: ", label3));
                    this.variableDecl = new VariableDecl(Type.boolType);
                }
            } else if (operatorType == OperatorType.NE) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    String label1 = coder.newLabel();
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText("c.eq.s $f0,$f1");
                    coder.addText("li $s4,1");
                    coder.addText(String.format("bc1t %s", label1));
                    coder.addText("li $s4,0");
                    coder.addText(String.format("%s: ", label1));
                    this.variableDecl = new VariableDecl(Type.boolType);
                } else if (firstOperand.variableDecl.type == Type.boolType ||
                        firstOperand.variableDecl.type == Type.intType ||
                        firstOperand.variableDecl.type == Type.nullType ||
                        firstOperand.variableDecl.type instanceof ClassType ||
                        firstOperand.variableDecl.type instanceof ArrayType) {
                    coder.addText("seq $s4,$s1,$s0");
                    this.variableDecl = new VariableDecl(Type.boolType);
                } else if (firstOperand.variableDecl.type == Type.stringType) {
                    String label1 = coder.newLabel(), label2 = coder.newLabel(), label3 = coder.newLabel();
                    coder.addText("li $s4,1");
                    coder.addText(String.format("%s: ", label1));
                    coder.addText("lb $s3,0($s1)");
                    coder.addText("lb $s2,0($s0)");
                    coder.addText(String.format("beq $s2,$s3,%s", label2));
                    coder.addText("li $s4,0");
                    coder.addText(String.format("j %s", label3));
                    coder.addText(String.format("%s: ", label2));
                    coder.addText("addi $s1,$s1,1");
                    coder.addText("addi $s0,$s0,1");
                    coder.addText(String.format("bne $s2,$zero,%s", label1));
                    coder.addText(String.format("%s: ", label3));
                    this.variableDecl = new VariableDecl(Type.boolType);
                }
                coder.addText("nor $s4,$s4,$s4");
            } else if (operatorType == OperatorType.ADD
                    || operatorType == OperatorType.SUB
                    || operatorType == OperatorType.MUL) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText(operatorType.toString().toLowerCase() + ".s $f2,$f0,$f1");
                    coder.addText("mfc1 $s4,$f2");
                    this.variableDecl = new VariableDecl(Type.doubleType);
                } else if (firstOperand.variableDecl.type == Type.intType) {
                    coder.addText(operatorType.toString().toLowerCase() + " $s4,$s0,$s1");
                    this.variableDecl = new VariableDecl(Type.intType);
                }
            } else if (operatorType == OperatorType.DIV) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText("div.s $f2,$f0,$f1");
                    coder.addText("mfc1 $s4,$f2");
                    this.variableDecl = new VariableDecl(Type.doubleType);
                } else if (firstOperand.variableDecl.type == Type.intType) {
                    coder.addText("div $s0,$s1");
                    coder.addText("mflo $s4");
                    this.variableDecl = new VariableDecl(Type.intType);
                }
            } else if (operatorType == OperatorType.MOD) {
                if (firstOperand.variableDecl.type == Type.doubleType) {
                    coder.addText("mtc1 $s0,$f0");
                    coder.addText("mtc1 $s1,$f1");
                    coder.addText("div.s $f2,$f0,$f1");
                    coder.addText("round.w.s $f3,$f2");
                    coder.addText("mul.s $f4,$f3,$f1");
                    coder.addText("sub.s $f5,$f0,$f4");
                    coder.addText("mfc1 $s4,$f5");
                    this.variableDecl = new VariableDecl(Type.doubleType);
                } else if (firstOperand.variableDecl.type == Type.intType) {
                    coder.addText("div $s0,$s1");
                    coder.addText("mfhi $s4");
                    this.variableDecl = new VariableDecl(Type.intType);
                }
            }
        }
        this.variableDecl.location = coder.stackOffset;
        coder.stackOffset -= 4;
        this.variableDecl.variableType = VariableType.LOCAL;
        coder.addText(String.format("sw $s4,%d($fp)", this.variableDecl.location));
    }
}