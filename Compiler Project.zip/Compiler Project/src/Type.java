public class Type {
    public static Type intType = new Type();
    public static Type doubleType = new Type();
    public static Type stringType = new Type();
    public static Type boolType = new Type();
    public static Type voidType = new Type();
    public static Type nullType = new Type();
}

class ArrayType extends Type {
    Type type;

    ArrayType(Type type) {
        this.type = type;
    }
}

class ClassType extends Type {
    ID id;

     ClassType(ID id) {
        this.id = id;
    }
}

