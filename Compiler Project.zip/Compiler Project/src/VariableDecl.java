public class VariableDecl extends Decl {
    Type type;
    ID id;
    int location;
    VariableType variableType;

    public VariableDecl(Type type, ID id) {
        this.type = type;
        this.id = id;
    }

    public VariableDecl(Type type) {
        this.type = type;
        this.id = null;
    }

    @Override
    public void coder(Coder coder) {
        System.out.println("here.");
    }
}
