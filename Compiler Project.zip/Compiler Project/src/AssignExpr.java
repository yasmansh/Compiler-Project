public class AssignExpr extends Expr {
    Lvalue lvalue;
    Expr expr;

    AssignExpr(Lvalue lvalue, Expr expr) {
        this.lvalue = lvalue;
        this.expr = expr;
    }

    @Override
    void coder(Coder coder) {
        expr.coder(coder);
        lvalue.coder(coder);
        this.variableDecl = expr.variableDecl;
        coder.addText(String.format("lw $s0,%d($fp)", lvalue.variableDecl.location));
        coder.addText(String.format("lw $s1,%d($fp)", expr.variableDecl.location));
        coder.addText("sw $s1,0($s0)");
    }
}