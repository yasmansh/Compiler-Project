import java.util.ArrayList;

public class FunctionDecl extends Decl {
    ID id;
    Type type;
    ArrayList<VariableDecl> formals;
    Block body;
    int location;
    ClassType parClass;

    FunctionDecl(ArrayList<VariableDecl> formals, Block body, Type type, ID id) {
        this.formals = formals;
        this.type = type;
        this.body = body;
        this.id = id;
    }

    void init() {
        if (parClass != null) {
            formals.add(new VariableDecl(parClass, new ID("this")));
        }
        int ptr = 4 * (formals.size() + 1);
        for (VariableDecl formal : formals) {
            formal.location = ptr;
            formal.variableType = VariableType.PARAMETER;
            ptr -= 4;
        }
    }

    @Override
    public void coder(Coder coder) {
        coder.addScope();
        for (VariableDecl formal : formals) {
            coder.topScope().put(formal.id, formal);
        }
        coder.addText(String.format("%s: ", getLabel()));
        coder.addText("sw $ra,4($fp)");
        coder.stackOffset = -4;
        body.coder(coder);
        Return ret = new Return(null);
        ret.coder(coder);
        coder.popScope();
    }

    public String getLabel() {
        if (parClass != null) {
            return String.format("FuncLabel%s", parClass.id.name + "." + id.name);
        } else {
            return String.format("FuncLabel%s", id.name);
        }
    }
}
