import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.nio.file.Paths;

public class Main {
    public static void main(String[] args) {
        scanner s = new scanner(args);
        Parser parser = new Parser(s);
        boolean error = false;
        Path currentRelativePath = Paths.get("");
        try (Writer writer = new BufferedWriter(new OutputStreamWriter(
                new FileOutputStream("tc.s"), StandardCharsets.UTF_8))) {
            parser.setWriter(writer);
            parser.parse();
        } catch (IOException ex) {
            error = true;
        } catch (Exception e) {
            error = true;
            e.printStackTrace();
        }

        if (scanner.error)
            System.out.println("error");
        if (error)
            System.out.println("error");
    }
}