public class IfStmt extends Stmt {
    private Expr condition;
    private Stmt ifBody;
    private Stmt elseBody;

    IfStmt(Expr condition, Stmt ifBody, Stmt elseBody) {
        this.condition = condition;
        this.ifBody = ifBody;
        this.elseBody = elseBody;
    }

    IfStmt(Expr condition, Stmt ifBody) {
        this.condition = condition;
        this.ifBody = ifBody;
        this.elseBody = null;
    }

    @Override
    void coder(Coder coder) {
        condition.coder(coder);
        coder.addText(String.format("lw $s0,%d($fp)", condition.variableDecl.location));
        String label1 = coder.newLabel(), label2 = null;
        if (elseBody != null)
            label2 = coder.newLabel();
        coder.addText(String.format("beq $s0,$zero,%s", label1));
        ifBody.coder(coder);
        if (elseBody != null)
            coder.addText(String.format("j %s", label2));
        coder.addText(String.format("%s:", label1));
        if (elseBody != null) {
            elseBody.coder(coder);
            coder.addText(String.format("%s:", label2));
        }
    }
}
