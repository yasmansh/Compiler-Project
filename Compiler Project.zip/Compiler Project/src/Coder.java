import java.util.ArrayList;
import java.util.HashMap;

public class Coder {
    ArrayList<String> data = new ArrayList<>();
    ArrayList<String> text = new ArrayList<>();
    ArrayList<HashMap<ID, VariableDecl>> varTable = new ArrayList<>();
    ArrayList<HashMap<ID, FunctionDecl>> funcTable = new ArrayList<>();
    HashMap<ID, ClassDecl> classTable = new HashMap<>();
    private ArrayList<String> loopLabels = new ArrayList<>();
    int stackOffset = -4;
    private int numOfLine = 0;
    private int labelCounter = 0;
    private int intCounter = 0;
    private int doubleCounter = 0;
    private int stringCounter = 0;
    private int nullCounter = 0;
    private int boolCounter = 0;

    public Coder() {
        funcTable.add(new HashMap<>());
        varTable.add(new HashMap<>());

        addData(".data");
        addData("NewLine:\t.asciiz\t\"\\n\"");
        addData("ReadLineAddress:\t.space\t4");
        addData("BooleanL:\t.space\t8");
        addData("True:\t.asciiz\t\"true\"");
        addData("False:\t.asciiz\t\"false\"");
        addData("DoubleLabel:\t.float\t10000.0");
        addData("HalfDoubleLabel:\t.float\t0.5");
        addData("ReturnL:\t.asciiz\t\"\\r\"");

        addText(".text");
        addText("main:");
        addText("j Initial");
    }

    public void addData(String str) {
        if (!str.equals(".data")) {
            data.add("\t" + str);
        } else {
            data.add(str);
        }
        data.add(".align 2");
    }

    public void addText(String str) {
        if (!str.contains(":") && //not a label
                !(str.equals(".text") || str.equals("main:"))) {
            text.add("\t" + str);
        } else {
            text.add(str);
        }
    }

    public void addScope() {
        varTable.add(new HashMap<>());
    }

    public HashMap<ID, VariableDecl> topScope() {
        return varTable.get(varTable.size() - 1);
    }

    public void popScope() {
        varTable.remove(varTable.size() - 1);
    }

    public String newLabel() {
        labelCounter++;
        return String.format("llaabbeell%d", labelCounter);
    }

    public VariableDecl findVar(ID iid) {
        for (int i = varTable.size() - 1; i >= 0; i--) {
            if (varTable.get(i).containsKey(iid)) {
                return varTable.get(i).get(iid);
            }
        }
        return null;
    }

    int newLocation() {
        int tmp = stackOffset;
        stackOffset -= 4;
        return tmp;
    }

    String topLoop() {
        return loopLabels.get(loopLabels.size() - 1);
    }

    void popLoop() {
        loopLabels.remove(loopLabels.size() - 1);
    }

    void pushLoop(String label) {
        loopLabels.add(label);
    }

    String intLabel() {
        intCounter++;
        return String.format("intLabel%d", intCounter);
    }

    String nullLabel() {
        nullCounter++;
        return String.format("nullLabel%d", nullCounter);
    }

    String stringLabel() {
        stringCounter++;
        return String.format("stringLabel%d", stringCounter);
    }

    String doubleLabel() {
        doubleCounter++;
        return String.format("doubleLabel%d", doubleCounter);
    }

    String boolLabel() {
        boolCounter++;
        return String.format("boolLabel%d", boolCounter);
    }

    void printStringSysCall() {
        this.addText("li $v0,4"); // syscall for print string
        this.addText("syscall");
    }

    void printIntegerSysCall() {
        this.addText("li $v0,1"); //syscall for print int
        this.addText("syscall");
    }

    void printFloatSysCall() {
        this.addText("li $v0,2"); //syscall for print float
        this.addText("syscall");
    }

    void exitSysCall() {
        this.addText("li $v0,10"); // syscall for exit
        this.addText("syscall");
    }

}
