
import java.util.ArrayList;

 class Print extends Stmt {
    private ArrayList<Expr> expressions;

    Print(ArrayList<Expr> exprs) {
        this.expressions = exprs;
    }

    @Override
    void coder(Coder coder) {
        for (Expr expression : expressions) {
            printExpr(expression, coder);
        }
        printNewLine(coder);
    }

    void printExpr(Expr expr, Coder coder) {
        expr.coder(coder);
        if (expr.variableDecl.type == Type.intType) {
            coder.addText(String.format("lw $a0,%d($fp)", expr.variableDecl.location));
            coder.printIntegerSysCall();
        } else if (expr.variableDecl.type == Type.doubleType) {
            coder.addText(String.format("l.s $f12,%d($fp)",expr.variableDecl.location));
            coder.printFloatSysCall();
        } else if (expr.variableDecl.type == Type.boolType) {
            coder.addText("la $a0,BooleanL");
            coder.addText(String.format("lw $s0,%d($fp)", expr.variableDecl.location));
            coder.addText("sll $s0,$s0,2");
            coder.addText("add $a0,$s0,$a0");
            coder.addText("lw $a0,0($a0)");
            coder.printStringSysCall();
        } else if (expr.variableDecl.type == Type.stringType) {
            coder.addText(String.format("lw $a0,%d($fp)", expr.variableDecl.location));
            coder.printStringSysCall();
        } else if (expr.variableDecl.type == Type.nullType) {
            System.out.println("null");
            coder.addText(String.format("lw $a0,%d($fp)", expr.variableDecl.location));
            coder.printStringSysCall();
        }
    }

    void printNewLine(Coder coder) {
        coder.addText("la $a0,NewLine");
        coder.printStringSysCall();
    }
}
