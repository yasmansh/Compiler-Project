public class LvalueExpr extends Expr {
    private Lvalue lvalue;

    LvalueExpr(Lvalue lvalue) {
        this.lvalue = lvalue;
    }

    @Override
    void coder(Coder coder) {
        lvalue.coder(coder);
        this.variableDecl = new VariableDecl(lvalue.variableDecl.type, null);
        this.variableDecl.variableType = VariableType.LOCAL;
        this.variableDecl.location = coder.newLocation();
        coder.addText(String.format("lw $s0,%d($fp)", lvalue.variableDecl.location));
        coder.addText("lw $s1,0($s0)");
        coder.addText(String.format("sw $s1,%d($fp)", this.variableDecl.location));
    }
}
