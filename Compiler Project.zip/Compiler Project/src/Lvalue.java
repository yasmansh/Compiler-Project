abstract class Lvalue {
    VariableDecl variableDecl;

    abstract void coder(Coder coder);
}

class ArrayLvalue extends Lvalue {
    Expr expr;
    Expr index;

    ArrayLvalue(Expr expr, Expr index) {
        this.expr = expr;
        this.index = index;
    }

    @Override
    void coder(Coder coder) {
        expr.coder(coder);
        index.coder(coder);
        this.variableDecl = new VariableDecl(((ArrayType) expr.variableDecl.type).type, null);
        this.variableDecl.location = coder.newLocation();
        coder.addText(String.format("lw $s0,%d($fp)", expr.variableDecl.location));
        coder.addText(String.format("lw $s1,%d($fp)", index.variableDecl.location));
        coder.addText("addi $s1,$s1,1");
        coder.addText("sll $s1,$s1,2");
        coder.addText("add $s4,$s1,$s0");
        coder.addText(String.format("sw $s4,%d($fp)", this.variableDecl.location));
    }
}

class FieldLvalue extends Lvalue {
    Expr expr;
    ID id;

    FieldLvalue(Expr expr, ID id) {
        this.expr = expr;
        this.id = id;
    }

    @Override
    void coder(Coder coder) {
        if (expr == null) {
            VariableDecl variableDecl = coder.findVar(id);
            if (variableDecl == null) {
                return;
            }
            switch (variableDecl.variableType) {
                case LOCAL:
                case PARAMETER:
                    coder.addText(String.format("addi $s0,$fp,%d", variableDecl.location));
                    this.variableDecl = new VariableDecl(variableDecl.type, null);
                    this.variableDecl.location = coder.newLocation();
                    coder.addText(String.format("sw $s0,%d($fp)", this.variableDecl.location));
                    return;
                case GLOBAL:
                    coder.addText(String.format("addi $s0,$s7,%d", variableDecl.location));
                    this.variableDecl = new VariableDecl(variableDecl.type, null);
                    this.variableDecl.location = coder.newLocation();
                    coder.addText(String.format("sw $s0,%d($fp)", this.variableDecl.location));
                    return;
                case FIELD:
                    this.expr = new This();
                    break;
                default:
                    return;
            }
        }
        expr.coder(coder);
        Type type = expr.variableDecl.type;
        if (!(type instanceof ClassType)) {
            return;
        }
        ID id = ((ClassType) type).id;
        ClassDecl classDecl = coder.classTable.get(id);
        if (classDecl == null) {
            return;
        }
        VariableDecl var = null;
        for (VariableDecl variableDecl : classDecl.fields) {
            if (variableDecl.id.equals(this.id)) {
                var = variableDecl;
            }
        }
        if (var == null) {
            return;
        }
        this.variableDecl = new VariableDecl(var.type, null);
        this.variableDecl.location = coder.newLocation();
        coder.addText(String.format("lw $s0,%d($fp)", expr.variableDecl.location));
        coder.addText(String.format("addi $s0,$s0,%d", var.location));
        coder.addText(String.format("sw $s0,%d($fp)", this.variableDecl.location));
    }
}