public enum OperatorType {
    NOT, SINGLESUB, OR, AND, L,G,LE,GE,E,NE,ADD,SUB,MUL,DIV,MOD
}
