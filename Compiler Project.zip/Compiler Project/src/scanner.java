import java_cup.runtime.DefaultSymbolFactory;
import java_cup.runtime.Symbol;
import java_cup.runtime.SymbolFactory;

import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import java.util.regex.Pattern;

class scanner {
    public static boolean error = false;
    private String[] args;
    private String inPath, outPath;

    public scanner(String[] args) {
        this.args = args;

        Scanner scanner = null;
        Path currentRelativePath = Paths.get("");
        String crp = currentRelativePath.toAbsolutePath().toString();
        try {
            inPath = crp + "Tests/t002-io2.d";
            scanner = new Scanner(new File(crp+"\\src\\tc.d"));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        outPath = crp + "\\src\\tcTokens.out";
        File wf = new File(outPath);
        if (!wf.exists()) {
            try {
                wf.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
//        if (args.length < 4) {
//            return;
//        }

//        Scanner scanner = null;
//        Path currentRelativePath = Paths.get("");
//        String crp = currentRelativePath.toAbsolutePath().toString();
//        try {
//            inPath = crp + "\\tests\\" + args[1];
//            scanner = new Scanner(new File(inPath));
//        } catch (FileNotFoundException e) {
//            e.printStackTrace();
//        }
//        outPath = crp + "\\scanner_outputs\\" + args[3];
//        File wf = new File(outPath);
//        if (!wf.exists()) {
//            try {
//                wf.createNewFile();
//            } catch (IOException e) {
//                e.printStackTrace();
//            }
//        }
        try (PrintWriter pw = new PrintWriter(new FileOutputStream(wf, false))) {
            boolean isComment = false;
            while (!error && scanner.hasNextLine()) {
                String input = scanner.nextLine();
                String inputString = input.substring(0);
                int onlyWhitespaceIndex = 0;
                while (onlyWhitespaceIndex < input.length() && isWhitespace(input.charAt(onlyWhitespaceIndex))) {
                    onlyWhitespaceIndex++;
                }
                if (onlyWhitespaceIndex == input.length())
                    continue;

                boolean match = true;
                boolean numberFlag = false;
                int index = 0;
                while (match && !error) {

                    match = false;
                    boolean keywordFlag = false;
                    String temp = "";
                    int i = 0;
                    if (numberFlag) {
                        input = input.substring(index);
                        numberFlag = false;
                    }

                    if (input.matches("")) {
                        break;
                    }
                    while (i < input.length() && (input.charAt(i) == ' ' || isWhitespace(input.charAt(i)))) {
                        i++;
                    }

                    input = input.substring(i);
                    i = 0;
                    if (i == input.length())
                        break;

                    if (Pattern.compile("^//").matcher(input).find()) {
                        input = "";
                        continue;
                    }

                    String check = input.charAt(i) + "";
                    if (isComment || Pattern.compile("^/\\*").matcher(input).find()) {
                        isComment = true;
                        String com = input.substring(input.length() - 2);
                        if (Pattern.compile("^\\*/").matcher(com).find()) {
                            isComment = false;
                        }
                        input = "";
                        continue;
                    }
                    if (Pattern.compile("^\"").matcher(check).find()) {
                        temp = temp + check;
                        i++;
                        if (i == input.length()) {
                            error = true;
                            break;
                        }
                        check = input.charAt(i) + "";
                        while (!Pattern.compile("^\"").matcher(check).find()) {
                            temp = temp + check;
                            i++;
                            if (i == input.length()) {
                                error = true;
                                break;
                            }
                            check = input.charAt(i) + "";
                        }
                        if (!error) {
                            temp = temp + "\"";
                            i++;
                            input = input.substring(i);
                            match = true;
                            pw.println("T_STRINGLITERAL " + temp);
                            continue;
                        } else {
                            continue;
                        }
                    }


                    switch (input.charAt(i)) {
                        case '+':
                            pw.println("+");
                            input = input.substring(i + 1);
                            match = true;
                            continue;

                        case '-':
                            pw.println("-");
                            input = input.substring(i + 1);
                            match = true;
                            continue;

                        case '*':
                            pw.println("*");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case '/':
                            pw.println("/");
                            input = input.substring(i + 1);
                            match = true;
                            continue;

                        case '%':
                            pw.println("%");
                            input = input.substring(i + 1);
                            match = true;
                            continue;

                        case '<':
                            if (input.length() == i + 1 || input.charAt(i + 1) != '=') {
                                pw.println("<");
                                input = input.substring(i + 1);
                                match = true;
                                continue;
                            } else {
                                pw.println("<=");
                                input = input.substring(i + 2);
                                match = true;
                                continue;
                            }
                        case '>':
                            if (input.length() == i + 1 || input.charAt(i + 1) != '=') {
                                pw.println(">");
                                input = input.substring(i + 1);
                                match = true;
                                continue;
                            } else {
                                pw.println(">=");
                                input = input.substring(i + 2);
                                match = true;
                                continue;
                            }
                        case '=':
                            if (input.length() == i + 1 || input.charAt(i + 1) != '=') {
                                pw.println("=");
                                input = input.substring(i + 1);
                                match = true;
                                continue;
                            } else {
                                pw.println("==");
                                input = input.substring(i + 2);
                                match = true;
                                continue;
                            }
                        case '!':
                            if (input.length() == i + 1 || input.charAt(i + 1) != '=') {
                                pw.println("!");
                                input = input.substring(i + 1);
                                match = true;
                                continue;
                            } else {
                                pw.println("!=");
                                input = input.substring(i + 2);
                                match = true;
                                continue;
                            }
                        case '&':
                            if (input.length() == i + 1 || input.charAt(i + 1) != '&') {
                                pw.println("&");
                                input = input.substring(i + 1);
                                match = true;
                                continue;
                            } else {
                                pw.println("&&");
                                input = input.substring(i + 2);
                                match = true;
                                continue;
                            }
                        case '|':
                            if (input.length() == i + 1 || input.charAt(i + 1) != '|') {
                                pw.println("|");
                                input = input.substring(i + 1);
                                match = true;
                                continue;
                            } else {
                                pw.println("||");
                                input = input.substring(i + 2);
                                match = true;
                                continue;
                            }
                        case ';':
                            pw.println(";");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case ',':
                            pw.println(",");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case '.':
                            pw.println(".");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case '{':
                            pw.println("{");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case '}':
                            pw.println("}");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case '[':
                            pw.println("[");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case ']':
                            pw.println("]");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case '(':
                            pw.println("(");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                        case ')':
                            pw.println(")");
                            input = input.substring(i + 1);
                            match = true;
                            continue;
                    }


                    check = input.charAt(i) + "";
                    if (Pattern.compile("^[a-zA-Z]").matcher(check).find()) {
                        temp = temp + check;
                        i++;
                        if (i != input.length()) {
                            check = input.charAt(i) + "";

                            while (Pattern.compile("^[a-zA-Z]").matcher(check).find() ||
                                    Pattern.compile("^[0-9]").matcher(check).find() ||
                                    Pattern.compile("^\\_").matcher(check).find()) {
                                temp = temp + check;
                                i++;
                                if (i == input.length()) {
                                    break;
                                }
                                check = input.charAt(i) + "";

                                if (check.matches(" ")) {
                                    break;
                                }
                            }
                        }
                    }


                    input = input.substring(i);
                    if ((Pattern.compile("^[a-zA-Z]").matcher(temp).find())) {
                        keywordFlag = true;
                    }
                    if (keywordFlag) {
                        if (temp.matches("void")) {
                            pw.println("void");
                            match = true;
                            continue;
                        } else if (temp.matches("int")) {
                            pw.println("int");
                            match = true;
                            continue;
                        } else if (temp.matches("double")) {
                            pw.println("double");
                            match = true;
                            continue;
                        } else if (temp.matches("bool")) {
                            pw.println("bool");
                            match = true;
                            continue;
                        } else if (temp.matches("string")) {
                            pw.println("string");
                            match = true;
                            continue;
                        } else if (temp.matches("class")) {
                            pw.println("class");
                            match = true;
                            continue;
                        } else if (temp.matches("interface")) {
                            pw.println("interface");
                            match = true;
                            continue;
                        } else if (temp.matches("null")) {
                            pw.println("null");
                            match = true;
                            continue;
                        } else if (temp.matches("this")) {
                            pw.println("this");
                            match = true;
                            continue;
                        } else if (temp.matches("extends")) {
                            pw.println("extends");
                            match = true;
                            continue;
                        } else if (temp.matches("implements")) {
                            pw.println("implements");
                            match = true;
                            continue;
                        } else if (temp.matches("for")) {
                            pw.println("for");
                            match = true;
                            continue;
                        } else if (temp.matches("while")) {
                            pw.println("while");
                            match = true;
                            continue;
                        } else if (temp.matches("if")) {
                            pw.println("if");
                            match = true;
                            continue;
                        } else if (temp.matches("else")) {
                            pw.println("else");
                            match = true;
                            continue;
                        } else if (temp.matches("return")) {
                            pw.println("return");
                            match = true;
                            continue;
                        } else if (temp.matches("break")) {
                            pw.println("break");
                            match = true;
                            continue;
                        } else if (temp.matches("new")) {
                            pw.println("new");
                            match = true;
                            continue;
                        } else if (temp.matches("NewArray")) {
                            pw.println("NewArray");
                            match = true;
                            continue;
                        } else if (temp.matches("Print")) {
                            pw.println("Print");
                            match = true;
                            continue;
                        } else if (temp.matches("ReadInteger")) {
                            pw.println("ReadInteger");
                            match = true;
                            continue;
                        } else if (temp.matches("ReadLine")) {
                            pw.println("ReadLine");
                            match = true;
                            continue;
                        } else if (temp.matches("true")) {
                            pw.println("T_BOOLEANLITERAL true");
                            match = true;
                            continue;
                        } else if (temp.matches("false")) {
                            pw.println("T_BOOLEANLITERAL false");
                            match = true;
                            continue;
                        } else {
                            if (temp.length() < 32) {
                                pw.println("T_ID " + temp);
                                match = true;
                            } else {
                                //pw.println("UNDEFINED_TOKEN")
                                error = true;
                            }
                            continue;
                        }
                    }

                    input = input.replaceAll("\\s\\s", " "); // whitespace
                    if (index == input.length()) // end of line
                        break;
                    while (index < input.length() && isWhitespace(input.charAt(index))) {
                        index++;
                    }

                    index = 0;
                    boolean hexFlag = false;
                    int firstIndex = index;
                    if (index < input.length() && isDecimalDigit(input.charAt(index))) {
                        firstIndex = index;
                        if (index + 1 < input.length() && input.charAt(index) == '0' &&
                                (input.charAt(index + 1) == 'X' || input.charAt(index + 1) == 'x'))
                            hexFlag = true;
                        while (index < input.length() && isDecimalDigit(input.charAt(index))) {
                            index++;
                        }
                        if (index < input.length() && input.charAt(index) == '.') {
                            index++;
                            while (index < input.length() && isDecimalDigit(input.charAt(index)))
                                index++;
                            if (index < input.length() && (input.charAt(index) == 'E' || input.charAt(index) == 'e')) {
                                index++;
                                if (index < input.length() && (input.charAt(index) == '+' || input.charAt(index) == '-')) {
                                    index++;
                                }
                                boolean flag = false;
                                while (index < input.length() && isDecimalDigit(input.charAt(index))) {
                                    flag = true;
                                    index++;
                                }
                                match = flag; // age 1.2e- qalat bashe(adade tavan bade 'E' nayad,qalat gereftam.)
                                if (match) {
                                    pw.println("T_DOUBLELITERAL " + input.substring(firstIndex, index));
                                    numberFlag = true;
                                }
                            } else {
                                match = true;
                                pw.println("T_DOUBLELITERAL " + input.substring(firstIndex, index));
                                numberFlag = true;
                            }
                        } else if (!hexFlag) {
                            match = true;
                            pw.println("T_INTLITERAL " + input.substring(firstIndex, index));
                            numberFlag = true;
                            continue;
                        }
                    }
                    if (hexFlag) {
                        index = firstIndex + 2;
                        int lastIndex = checkHex(input, index);
                        if (lastIndex != index) {
                            match = true;
                            index = lastIndex;
                            pw.println("T_INTLITERAL " + input.substring(firstIndex, lastIndex));
                            numberFlag = true;
                            continue;
                        } else {
                            match = true;
                            pw.println("T_INTLITERAL 0");
                            numberFlag = true;
                            index--;
                        }
                    }

                }
                if (!match && !input.isEmpty()) {
                    pw.println("UNDEFINED_TOKEN");
                    break;
                }
                if (error) {
                    pw.println("UNDEFINED_TOKEN");
                    error = true;
                    break;
                }
            }

        } catch (FileNotFoundException e1) {
            e1.printStackTrace();
        }
    }

    private static int checkHex(String input, int index) {
        int lastIndex = index;
        if (lastIndex < input.length() && isHexDigit(input.charAt(index))) {
            lastIndex++;
            while (lastIndex < input.length() && isHexDigit(input.charAt(lastIndex))) {
                lastIndex++;
            }
        }
        return lastIndex;
    }


    private static boolean isWhitespace(char ch) {
        switch (ch) {
            case '\u0009': // Tab
            case '\u000B': // Vertical Tab
            case '\u000C': // Form Feed
            case '\u0020': // Space
            case '\u00A0': // No-break space
            case '\uFEFF': // Byte Order Mark
            case '\n':     // Line Feed
            case '\r':     // Carriage Return
            case '\u2028': // Line Separator
            case '\u2029': // Paragraph Separator
            case '\u3000': // Ideographic Space
                return true;
            default:
                return false;
        }
    }

    private static boolean isLineTerminator(char ch) {
        switch (ch) {
            case '\f':
            case '\n': // Line Feed
            case '\r': // Carriage Return
            case '\u2028': // Line Separator
            case '\u2029': // Paragraph Separator
                return true;
            default:
                return false;
        }
    }

    private static boolean isDecimalDigit(char ch) {
        return (ch >= '0' && ch <= '9');
    }

    private static boolean isHexDigit(char ch) {
        return (isDecimalDigit(ch) || (ch >= 'a' && ch <= 'f') || (ch >= 'A' && ch <= 'F'));
    }

    private SymbolFactory sf = new DefaultSymbolFactory();

    private String next_line;
    File wf;
    Scanner scannerr;

    public void init() throws java.io.IOException {
        wf = new File(outPath);
        scannerr = new Scanner(new File(outPath));
    }

    public Symbol next_token() throws java.io.IOException {
        if (!scannerr.hasNextLine())
            return sf.newSymbol("EOF", sym.EOF);
        else
            next_line = scannerr.nextLine();
        switch (next_line.charAt(0)) {
            case ';':
                return sf.newSymbol("semi", sym.semi);
            case '+':
                return sf.newSymbol("plus", sym.plus);
            case '-':
                return sf.newSymbol("minus", sym.minus);
            case '*':
                return sf.newSymbol("mult", sym.mult);
            case '(':
                return sf.newSymbol("lPran", sym.lPran);
            case ')':
                return sf.newSymbol("rPran", sym.rPran);
            case '[':
                return sf.newSymbol("lBrack", sym.lBrack);
            case ']':
                return sf.newSymbol("rBrack", sym.rBrack);
            case '{':
                return sf.newSymbol("lCrosh", sym.lCrosh);
            case '}':
                return sf.newSymbol("rCrosh", sym.rCrosh);
            case ',':
                return sf.newSymbol("comma", sym.comma);
            case '.':
                return sf.newSymbol("dot", sym.dot);
            case '/':
                return sf.newSymbol("div", sym.div);
            case '%':
                return sf.newSymbol("mod", sym.mod);
            case '=':
                if (next_line.length() == 1)
                    return sf.newSymbol("assign", sym.assign);
                else
                    return sf.newSymbol("eq", sym.eq);
            case '&':
                return sf.newSymbol("and", sym.and);
            case '|':
                return sf.newSymbol("or", sym.or);
            case '!':
                if (next_line.length() == 1)
                    return sf.newSymbol("not", sym.not);
                else
                    return sf.newSymbol("neq", sym.neq);
            case '<':
                if (next_line.length() == 1)
                    return sf.newSymbol("le", sym.le);
                else
                    return sf.newSymbol("leq", sym.leq);
            case '>':
                if (next_line.length() == 1)
                    return sf.newSymbol("gt", sym.gt);
                else
                    return sf.newSymbol("gtq", sym.gtq);
        }
        if (next_line.equals("NewArray"))
            return sf.newSymbol("NewArray", sym.NewArray);
        if (next_line.equals("Print"))
            return sf.newSymbol("Print", sym.Print);
        if (next_line.equals("for"))
            return sf.newSymbol("forr", sym.forr);
        if (next_line.equals("break"))
            return sf.newSymbol("breakk", sym.breakk);
        if (next_line.equals("error"))
            return sf.newSymbol("error", sym.error);
        if (next_line.equals("while"))
            return sf.newSymbol("whilee", sym.whilee);
        if (next_line.equals("ReadInteger"))
            return sf.newSymbol("ReadInteger", sym.ReadInteger);
        if (next_line.equals("implements"))
            return sf.newSymbol("implementss", sym.implementss);
        if (next_line.equals("if"))
            return sf.newSymbol("iff", sym.iff);
        if (next_line.equals("return"))
            return sf.newSymbol("returnn", sym.returnn);
        if (next_line.equals("ReadLine"))
            return sf.newSymbol("ReadLine", sym.ReadLine);
        if (next_line.equals("void"))
            return sf.newSymbol("voidd", sym.voidd);
        if (next_line.equals("new"))
            return sf.newSymbol("neww", sym.neww);
        if (next_line.equals("else")) {
            return sf.newSymbol("elsee", sym.elsee);
        }
        if (next_line.equals("class")) {
            return sf.newSymbol("classs", sym.classs);
        }
        if (next_line.equals("int"))
            return sf.newSymbol("intt", sym.intt);
        if (next_line.equals("extends"))
            return sf.newSymbol("extendss", sym.extendss);
        if (next_line.equals("string"))
            return sf.newSymbol("sting", sym.string);
        if (next_line.equals("interface"))
            return sf.newSymbol("interfacee", sym.interfacee);
        if (next_line.equals("double"))
            return sf.newSymbol("doublee", sym.doublee);
        if (next_line.equals("this")) {
            return sf.newSymbol("thiss", sym.thiss);
        }
        if (next_line.equals("null"))
            return sf.newSymbol("nulll", sym.nulll);
        if (next_line.equals("bool")) {
            return sf.newSymbol("bool", sym.bool);
        }
        if (next_line.contains("T_ID")) {
            return sf.newSymbol("ident", sym.ident, next_line.substring(5));
        }
        if (next_line.contains("T_INTLITERAL")) {
            return sf.newSymbol("intConstant", sym.intConstant, next_line.substring(13));
        }
        if (next_line.contains("T_DOUBLELITERAL")) {
            return sf.newSymbol("doubleConstant", sym.doubleConstantL, next_line.substring(16));
        }
        if (next_line.contains("T_BOOLEANLITERAL")) {
            return sf.newSymbol("boolConstant", sym.boolConstant, next_line.substring(17));
        }
        if (next_line.contains("T_STRINGLITERAL")) {
            return sf.newSymbol("stringConstant", sym.stringConstant, next_line.substring(16));
        }
        return null;
    }
}