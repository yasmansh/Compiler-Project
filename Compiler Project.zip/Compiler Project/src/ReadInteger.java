public class ReadInteger extends Expr {
    @Override
    void coder(Coder coder) {
        readIntSysCall(coder);
        this.variableDecl = new VariableDecl(Type.intType, null);
        this.variableDecl.location = coder.newLocation();
        this.variableDecl.variableType = VariableType.LOCAL;
        coder.addText(String.format("sw $v0,%d($fp)", this.variableDecl.location));
    }

    private void readIntSysCall(Coder coder) {
        coder.addText("li $v0,5");
        coder.addText("syscall");
    }
}
