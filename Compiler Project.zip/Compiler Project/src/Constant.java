public class Constant extends Expr {
    @Override
    void coder(Coder coder) {
        this.coder(coder);
        this.variableDecl.location = coder.stackOffset;
        coder.stackOffset -= 4;
    }
}

class BoolConstant extends Constant {
    private boolean boolValue;

    BoolConstant(String value) {
        this.boolValue = value.equals("true");
    }

    @Override
    void coder(Coder coder) {
        String boolLabel = coder.boolLabel();
        coder.addData(String.format("%s: .word %d", boolLabel, (this.boolValue) ? 1 : 0));
        this.variableDecl = new VariableDecl(Type.boolType);
        this.variableDecl.location = coder.newLocation();
        coder.addText(String.format("lw $s0,%s", boolLabel));
        coder.addText(String.format("sw $s0,%d($fp)", this.variableDecl.location));
    }
}

class StringConstant extends Constant {
    private String string;

    StringConstant(String value) {
        this.string = value;
    }

    @Override
    void coder(Coder coder) {
        String stringLabel = coder.stringLabel();
        coder.addData(String.format("%s: .asciiz %s", stringLabel, this.string));
        this.variableDecl = new VariableDecl(Type.stringType);
        this.variableDecl.location = coder.newLocation();
        coder.addText(String.format("la $s0,%s", stringLabel));
        coder.addText(String.format("sw $s0,%d($fp)", this.variableDecl.location));
    }
}

class IntegerConstant extends Constant {
    private int value;

    IntegerConstant(String value) {
        if (value.startsWith("0X") || value.startsWith("0x")) {
            this.value = Integer.decode(value);
//            System.out.println(this.value);
        } else {
            this.value = Integer.parseInt(value);
        }
    }

    @Override
    void coder(Coder coder) {
        String intLabel = coder.intLabel();
        coder.addData(String.format("%s: .word %s", intLabel, this.value));
        this.variableDecl = new VariableDecl(Type.intType);
        this.variableDecl.location = coder.newLocation();
        coder.addText(String.format("lw $s0,%s", intLabel));
        coder.addText(String.format("sw $s0,%d($fp)", this.variableDecl.location));
    }
}

class DoubleConstant extends Constant {
    double doubleValue;

    DoubleConstant(String value) {
        this.doubleValue = Double.parseDouble(value);
    }

    @Override
    void coder(Coder coder) {
        String doubleLabel = coder.doubleLabel();
        coder.addData(String.format("%s: .float %s", doubleLabel, this.doubleValue));
        this.variableDecl = new VariableDecl(Type.doubleType);
        this.variableDecl.location = coder.newLocation();
        coder.addText(String.format("lw $s0,%s", doubleLabel));
        coder.addText(String.format("sw $s0,%d($fp)", this.variableDecl.location));
    }
}

class NullConstant extends Constant {
    @Override
    void coder(Coder coder) {
        String nullLabel = coder.nullLabel();
        coder.addData(String.format("%s: .asciiz %s", nullLabel, "null"));
        this.variableDecl = new VariableDecl(Type.nullType);
        this.variableDecl.location = coder.newLocation();
        coder.addText(String.format("la $s0,%s", nullLabel));
        coder.addText(String.format("sw $s0,%d($fp)", this.variableDecl.location));
    }
}
