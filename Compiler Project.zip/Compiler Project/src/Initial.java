import java.util.ArrayList;

public class Initial {
    private ArrayList<Decl> program;
    private ArrayList<VariableDecl> varDecls = new ArrayList<>();
    private ArrayList<ClassDecl> classDecls = new ArrayList<>();
    private ArrayList<FunctionDecl> funcDecls = new ArrayList<>();

    Initial(ArrayList<Decl> program) {
        this.program = program;
        for (Decl decl : program) {
            if (decl instanceof VariableDecl) {
                varDecls.add((VariableDecl) decl);
            }
            if (decl instanceof ClassDecl) {
                classDecls.add((ClassDecl) decl);
            }
            if (decl instanceof FunctionDecl) {
                funcDecls.add((FunctionDecl) decl);
            }
        }
    }

    public void coder(Coder coder) {
        int glbPtr = 0;
        for (VariableDecl variableDecl : varDecls) {
            variableDecl.variableType = VariableType.GLOBAL;
            variableDecl.location = glbPtr;
            glbPtr -= 4;
            coder.varTable.get(0).put(variableDecl.id, variableDecl);
        }
        for (FunctionDecl functionDecl : funcDecls)
            coder.funcTable.get(0).put(functionDecl.id, functionDecl);
        for (ClassDecl classDecl : classDecls)
            coder.classTable.put(classDecl.id, classDecl);
        for (ClassDecl classDecl : classDecls)
            classDecl.addFields(coder);
        for (FunctionDecl functionDecl : funcDecls)
            functionDecl.init();
        for (Decl decl : program)
            decl.coder(coder);
        for (ClassDecl classDecl : classDecls)
            classDecl.addVtable(coder);
        coder.addText("Initial: ");
        coder.addText("la $s0,BooleanL");
        coder.addText("la $s1,False");
        coder.addText("la $s4,True");
        coder.addText("sw $s1,0($s0)");
        coder.addText("sw $s4,4($s0)");
        coder.addText("move $s7,$sp");
        coder.addText(String.format("addi $fp,$sp,%d", glbPtr));
        for (ClassDecl classDecl : classDecls) {
            coder.addText(String.format("la $s0,%s", classDecl.classLabel));
            for (FunctionDecl method : classDecl.methods) {
                coder.addText(String.format("la $s1,%s", method.getLabel()));
                coder.addText(String.format("sw $s1,%d($s0)", classDecl.offsetOfMethod(method.id)));
            }
        }
        Stmt s = new Call(null, new ArrayList<>(), new ID("main"));
        s.coder(coder);
        coder.exitSysCall();
    }
}
