import java.util.ArrayList;
import java.util.Collections;

abstract public class Stmt {
    abstract void coder(Coder coder);
}

class Break extends Stmt {
    @Override
    void coder(Coder coder) {
        String outLabel = coder.topLoop();
        coder.addText("j "+ outLabel);
    }
}

class Return extends Stmt {
    Expr expr;

    Return(Expr expr) {
        this.expr = expr;
    }

    @Override
    void coder(Coder coder) {
        if (expr != null) {
            expr.coder(coder);
            coder.addText(String.format("lw $v0,%d($fp)", expr.variableDecl.location));
        }
        coder.addText("lw $s0,4($fp)");
        coder.addText("jr $s0");
    }
}


class Block extends Stmt {
    private ArrayList<VariableDecl> varDecls;
    private ArrayList<Stmt> stmts;

    Block(ArrayList<Stmt> blocks, ArrayList<VariableDecl> varDecls) {
        Collections.reverse(blocks);
        this.stmts = blocks;
        this.varDecls = varDecls;
    }

    public void coder(Coder coder) {
        coder.addScope();
        for (VariableDecl varDecl : varDecls) {
            varDecl.location = coder.stackOffset;
            varDecl.variableType = VariableType.LOCAL;
            coder.stackOffset -= 4;
            coder.topScope().put(varDecl.id, varDecl);
        }
        for (Stmt stmt : stmts) {
            stmt.coder(coder);
        }
        coder.popScope();
    }
}