public class ReadLine extends Expr {
    @Override
    void coder(Coder coder) {
        String label1 = coder.newLabel();
        String label2 = coder.newLabel();
        variableDecl = new VariableDecl(Type.stringType);
        variableDecl.location = coder.newLocation();

        coder.addText("addi $sp,$fp," + coder.stackOffset);
        coder.addText(label1 + ":");
        coder.addText("la $a0,ReadLineAddress");
        coder.addText("li $a1,2");
        coder.addText("li $v0,8"); // syscall for read string
        coder.addText("syscall");
        coder.addText("lb $s0,ReadLineAddress");
        coder.addText("sb $s0,0($sp)");
        coder.addText("lb $s1,ReturnL");
        coder.addText("sne $s4,$s1,$s0");
        coder.addText("sub $sp,$sp,$s4");
        coder.addText("lb $s1,NewLine");
        coder.addText("bne $s1,$s0," + label1);
        coder.addText("lb $s1,NewLine");
        coder.addText("bne $s0,$s1," + label1);
        coder.addText(String.format("addi $s4,$sp,%d", -coder.stackOffset));
        coder.addText("sub $s4,$fp,$s4");
        coder.addText("move $a0,$s4");
        coder.addText("li $v0,9"); //memory allocation
        coder.addText("syscall");
        coder.addText(String.format("sw $v0,%d($fp)", variableDecl.location));
        coder.addText("add $sp,$sp,$s4");
        coder.addText(label2 + ": ");
        coder.addText("lb $s0,0($sp)");
        coder.addText("addi $sp,$sp,-1");
        coder.addText("addi $s4,$s4,-1");
        coder.addText("sb $s0,0($v0)");
        coder.addText("addi $v0,$v0,1");
        coder.addText("bne $s4,$zero," + label2);
        coder.addText("sb $zero,-1($v0)");
    }
}
