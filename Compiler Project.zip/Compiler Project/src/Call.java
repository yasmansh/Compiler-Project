import java.util.ArrayList;

class Call extends Expr {
    Expr expr;
    ID id;
    private ArrayList<Expr> actuals;

    Call(Expr expr, ArrayList<Expr> actuals, ID id) {
        this.expr = expr;
        this.actuals = actuals;
        this.id = id;
    }

    @Override
    void coder(Coder coder) {
        if (coder.funcTable.size() > 1 &&
                coder.funcTable.get(1).containsKey(id)) {
            expr = new This();
        }
        if (id.name.equals("itob")) {
            intToBool(coder);
        } else if (id.name.equals("itod")) {
            intToDouble(coder);
        } else if (id.name.equals("btoi")) {
            boolToInt(coder);
        } else if (id.name.equals("dtoi")) {
            doubleToInt(coder);
        } else if (expr == null) {
            for (Expr actual : actuals) {
                actual.coder(coder);
            }
            FunctionDecl func = coder.funcTable.get(0).get(id);
            int offset = coder.stackOffset - 4 * (func.formals.size() + 1);
            coder.addText(String.format("sw $fp,%d($fp)", offset));
            for (int i = 0; i < actuals.size(); i++) {
                coder.addText(String.format("lw $s0,%d($fp)", actuals.get(i).variableDecl.location));
                coder.addText(String.format("sw $s0,%d($fp)", func.formals.get(i).location + offset));
            }
            coder.addText(String.format("addi $fp,$fp,%d", offset));
            coder.addText(String.format("jal %s", func.getLabel()));
            coder.addText("lw $fp,0($fp)");
            if (func.type != Type.voidType) {
                variableDecl = new VariableDecl(func.type);
                variableDecl.location = coder.newLocation();
                coder.addText(String.format("sw $v0,%d($fp)", variableDecl.location));
            }
        } else {
            actuals.add(expr);
            for (Expr actual : actuals) {
                actual.coder(coder);
            }
            if (expr.variableDecl.type instanceof ArrayType && id.name.equals("length") && actuals.size() == 1) {
                coder.addText(String.format("lw $s0,%d($fp)", expr.variableDecl.location));
                coder.addText("lw $s0,0($s0)");
                variableDecl = new VariableDecl(Type.intType);
                variableDecl.location = coder.newLocation();
                coder.addText(String.format("sw $s0,%d($fp)", variableDecl.location));
                return;
            }
            if (!(expr.variableDecl.type instanceof ClassType)) {
                return;
            }
            ClassDecl classDecl = coder.classTable.get(((ClassType) expr.variableDecl.type).id);
            FunctionDecl functionDecl = classDecl.getMethod(id);
            int offset = coder.stackOffset - 4 * (actuals.size() + 1);
            coder.addText(String.format("sw $fp,%d($fp)", offset));
            for (int i = 0; i < actuals.size(); i++) {
                coder.addText(String.format("lw $s0,%d($fp)", actuals.get(i).variableDecl.location));
                coder.addText(String.format("sw $s0,%d($fp)", functionDecl.formals.get(i).location + offset));
            }
            coder.addText(String.format("lw $s0,%d($fp)", expr.variableDecl.location));
            coder.addText("lw $s0,0($s0)");
            coder.addText(String.format("lw $s0,%d($s0)", classDecl.offsetOfMethod(id)));
            coder.addText(String.format("addi $fp,$fp,%d", offset));
            coder.addText("jalr $s0");
            coder.addText("lw $fp,0($fp)");
            if (functionDecl.type != Type.voidType) {
                variableDecl = new VariableDecl(functionDecl.type);
                variableDecl.location = coder.newLocation();
                coder.addText(String.format("sw $v0,%d($fp)", variableDecl.location));
            }
        }
    }

    private void doubleToInt(Coder coder) {
        this.variableDecl = new VariableDecl(Type.intType);
        this.variableDecl.location = coder.newLocation();
        Expr expr1 = actuals.get(0);
        expr1.coder(coder);
        coder.addText(String.format("l.s $f0,%d($fp)", expr1.variableDecl.location));
        coder.addText("cvt.w.s $f0,$f0");
        coder.addText(String.format("s.s $f0,%d($fp)", variableDecl.location));
    }

    private void boolToInt(Coder coder) {
        this.variableDecl = new VariableDecl(Type.intType);
        this.variableDecl.location = coder.newLocation();
        Expr expr1 = actuals.get(0);
        expr1.coder(coder);
        coder.addText(String.format("lw $s0,%d($fp)", expr1.variableDecl.location));
        coder.addText(String.format("sw $s0,%d($fp)", variableDecl.location));
    }

    private void intToDouble(Coder coder) {
        this.variableDecl = new VariableDecl(Type.doubleType);
        this.variableDecl.location = coder.newLocation();
        Expr expr = actuals.get(0);
        expr.coder(coder);
        coder.addText(String.format("l.s $f0,%d($fp)", expr.variableDecl.location));
        coder.addText("cvt.s.w $f0,$f0");
        coder.addText(String.format("s.s $f0,%d($fp)", variableDecl.location));
    }

    private void intToBool(Coder coder) {
        this.variableDecl = new VariableDecl(Type.boolType);
        this.variableDecl.location = coder.newLocation();
        Expr expr1 = actuals.get(0);
        expr1.coder(coder);
        coder.addText(String.format("lw $s0,%d($fp)", expr1.variableDecl.location));
        coder.addText("sne $s0,$s0,$zero");
        coder.addText(String.format("sw $s0,%d($fp)", variableDecl.location));
    }
}
