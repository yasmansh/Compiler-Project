class This extends Expr {
    @Override
    void coder(Coder coder) {
        VariableDecl variableDecl = coder.findVar(new ID("this"));
        if (variableDecl == null) {
            return;
        }
        this.variableDecl = variableDecl;
    }
}
