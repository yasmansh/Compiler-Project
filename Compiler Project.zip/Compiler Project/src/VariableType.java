public enum VariableType {
    GLOBAL, LOCAL, FIELD, PARAMETER
}
