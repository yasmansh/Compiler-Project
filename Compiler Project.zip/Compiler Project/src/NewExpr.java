public class NewExpr extends Expr {
    ClassType type;

    NewExpr(ClassType type) {
        this.type = type;
    }

    @Override
    void coder(Coder coder) {
        ClassDecl classDecl = coder.classTable.get(type.id);
        if (classDecl == null) {
            return;
        }

        coder.addText(String.format("li $a0,%d", (classDecl.fields.size() + 1) * 4));
        coder.addText("li $v0,9");
        coder.addText("syscall");
        this.variableDecl = new VariableDecl(type, null);
        this.variableDecl.location = coder.newLocation();
        this.variableDecl.variableType = VariableType.LOCAL;
        coder.addText(String.format("la   $s0,%s", classDecl.classLabel));
        coder.addText("sw $s0,0($v0)");
        coder.addText(String.format("sw $v0,%d($fp)", variableDecl.location));
    }
}
