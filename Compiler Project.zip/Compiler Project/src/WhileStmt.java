class WhileStmt extends Stmt {
    Expr condition;
    Stmt body;

    WhileStmt(Expr condition, Stmt body) {
        this.condition = condition;
        this.body = body;
    }

    @Override
    void coder(Coder coder) {
        String label1 = coder.newLabel();
        String label2 = coder.newLabel();
        coder.pushLoop(label2);
        coder.addText(label1 + ":");
        condition.coder(coder);
        coder.addText("lw $s0," + condition.variableDecl.location + "($fp)");
        coder.addText("beq $s0,$zero," + label2);
        body.coder(coder);
        coder.addText("j " + label1);
        coder.addText(label2 + ":");
        coder.popLoop();
    }
}
